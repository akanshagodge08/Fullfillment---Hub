// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable, integer, text } from 'drizzle-orm/sqlite-core';
export const workspace = sqliteTable('workspace', { id: integer('id').primaryKey(), version: integer('version').notNull(), data: text('data').notNull() });
export const authSessions = sqliteTable('auth_sessions', {tokenHash:text('token_hash').primaryKey(),email:text('email').notNull(),expiresAt:integer('expires_at').notNull()});
export const authAttempts = sqliteTable('auth_attempts', {id:text('id').primaryKey(),attempts:integer('attempts').notNull(),resetAt:integer('reset_at').notNull()});
