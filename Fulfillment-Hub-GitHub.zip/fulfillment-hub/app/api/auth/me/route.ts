import {getUser,reply} from '@/lib/auth';
export async function GET(req:Request){try{const user=await getUser(req.headers.get('cookie'));return user?reply({user}):reply({error:'Please sign in.'},401);}catch{return reply({error:'Session unavailable.'},503);}}
