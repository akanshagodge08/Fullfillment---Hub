import {accounts,authDb,demoEnabled,sameOrigin,digest,cookie,reply} from '@/lib/auth';
export async function POST(req:Request){
 if(!sameOrigin(req))return reply({error:'Invalid request origin.'},403);
 if(!demoEnabled(req))return reply({error:'Demo sign-in is not enabled on this host.'},403);
 try{
 const body:any=await req.json();const email=typeof body.email==='string'?body.email.trim().toLowerCase():'';const password=typeof body.password==='string'?body.password:'';
 if(email.length>100||password.length>128)return reply({error:'Invalid email or password.'},400);
 const now=Date.now();const bucket='login';const db=authDb();
 await db.prepare('INSERT OR IGNORE INTO auth_attempts (id,attempts,reset_at) VALUES (?,0,?)').bind(bucket,now+60000).run();
 await db.prepare('UPDATE auth_attempts SET attempts=CASE WHEN reset_at<=? THEN 1 ELSE attempts+1 END,reset_at=CASE WHEN reset_at<=? THEN ? ELSE reset_at END WHERE id=?').bind(now,now,now+60000,bucket).run();
 const limit=await db.prepare('SELECT attempts FROM auth_attempts WHERE id=?').bind(bucket).first<{attempts:number}>();
 if((limit?.attempts||0)>10)return reply({error:'Too many attempts. Please wait one minute.'},429);
 const a=accounts.find(a=>a.email===email);const actual=await digest(password);const expected=await digest(a?.password||'invalid-placeholder');let diff=0;for(let i=0;i<actual.length;i++)diff|=actual.charCodeAt(i)^expected.charCodeAt(i);
 if(!a||diff!==0)return reply({error:'Incorrect email or password.'},401);
 const token=Array.from(crypto.getRandomValues(new Uint8Array(32))).map(v=>v.toString(16).padStart(2,'0')).join('');
 await db.prepare('DELETE FROM auth_sessions WHERE expires_at<=?').bind(now).run();
 await db.prepare('INSERT INTO auth_sessions (token_hash,email,expires_at) VALUES (?,?,?)').bind(await digest(token),a.email,now+8*3600000).run();
 return reply({user:{email:a.email,name:a.name,role:a.role}},200,{'Set-Cookie':cookie(token,28800,req)});
 }catch(e){console.error(e);return reply({error:'Sign-in is unavailable. Please retry.'},503);}
}

