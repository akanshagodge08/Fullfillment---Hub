import {headers} from 'next/headers';
import {redirect} from 'next/navigation';
import {getUser} from '@/lib/auth';
import Dashboard from './dashboard';
export const dynamic='force-dynamic';
export default async function Home(){const h=await headers();const user=await getUser(h.get('cookie'));if(!user)redirect('/login');return <Dashboard user={user}/>;}
