import { env } from 'cloudflare:workers';
export const accounts = [
 {email:'office@xyz.demo',name:'Office team',role:'office',password:'OfficeDemo!2026'},
 {email:'warehouse@xyz.demo',name:'Warehouse team',role:'warehouse',password:'WarehouseDemo!2026'},
];
export function authDb(){if(!env.DB)throw Error('Database unavailable');return env.DB;}
export function isLocal(req:Request){return ['localhost','127.0.0.1','[::1]'].includes(new URL(req.url).hostname);}
export function demoEnabled(req:Request){return isLocal(req)||(env as unknown as {PUBLIC_DEMO?:string}).PUBLIC_DEMO==='true';}
export function sameOrigin(req:Request){return req.headers.get('origin')===new URL(req.url).origin;}
export async function digest(value:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(b=>b.toString(16).padStart(2,'0')).join('');}
export async function getUser(cookie:string|null){const token=cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith('hub_session='))?.slice(12);if(!token||!/^[a-f0-9]{64}$/.test(token))return null;const row=await authDb().prepare('SELECT email FROM auth_sessions WHERE token_hash=? AND expires_at>?').bind(await digest(token),Date.now()).first<{email:string}>();const a=accounts.find(a=>a.email===row?.email);return a?{email:a.email,name:a.name,role:a.role}:null;}
export function cookie(value:string,maxAge:number,req:Request){return `hub_session=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${new URL(req.url).protocol==='https:'?'; Secure':''}`;}
export function reply(body:unknown,status=200,headers:Record<string,string>={}){return Response.json(body,{status,headers:{'Cache-Control':'no-store',...headers}});}

