import assert from 'node:assert/strict';
const base='http://127.0.0.1:5174';
const post=(url,body,cookie)=>fetch(base+url,{method:'POST',headers:{Origin:base,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:JSON.stringify(body)});
assert.equal((await fetch(base+'/api/hub')).status,401);
assert.equal((await post('/api/hub',{})).status,401);
const root=await fetch(base+'/',{redirect:'manual'});assert.ok([302,303,307,308].includes(root.status));assert.match(root.headers.get('location'),/login/);
assert.equal((await post('/api/auth/login',{email:'office@xyz.demo',password:'wrong'})).status,401);
for(const [email,password] of [['office@xyz.demo','OfficeDemo!2026'],['warehouse@xyz.demo','WarehouseDemo!2026']]){
 const login=await post('/api/auth/login',{email,password});assert.equal(login.status,200);const raw=login.headers.get('set-cookie');assert.match(raw,/HttpOnly/);assert.match(raw,/SameSite=Strict/);const cookie=raw.split(';')[0];
 const hub=await fetch(base+'/api/hub',{headers:{Cookie:cookie}});assert.equal(hub.status,200);assert.equal((await hub.json()).state.orders.length,18);
 const me=await fetch(base+'/api/auth/me',{headers:{Cookie:cookie}});assert.equal((await me.json()).user.email,email);
 assert.equal((await fetch(base+'/',{headers:{Cookie:cookie}})).status,200);
 const cross=await fetch(base+'/api/auth/logout',{method:'POST',headers:{Cookie:cookie,Origin:'http://evil.example'}});assert.equal(cross.status,403);
 assert.equal((await post('/api/auth/logout',{},cookie)).status,200);
 assert.equal((await fetch(base+'/api/hub',{headers:{Cookie:cookie}})).status,401);
}
console.log('PASS: protected page/API, invalid credentials, both accounts, persistent session, CSRF protection, logout revocation.');
